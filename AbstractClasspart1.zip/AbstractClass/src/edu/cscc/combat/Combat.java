package edu.cscc.combat;

public interface Combat {
    int MAX_ATTACK_ROLL = 20;
    int AUTOMATIC_FAILURE = 1;
    int AUTOMATIC_SUCCESS = 20;
    int BASE_DODGE_SCORE = 10;
}
