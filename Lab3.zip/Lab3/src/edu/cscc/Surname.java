package edu.cscc;

public class Surname {
    private String Name;
    private int Rank;

    public Surname(String name, int rank) {
        Name = name;
        Rank = rank;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public int getRank() {
        return Rank;
    }

    public void setRank(int rank) {
        Rank = rank;
    }

    //TODO Add properties, constructor, and getters/setters here.
}