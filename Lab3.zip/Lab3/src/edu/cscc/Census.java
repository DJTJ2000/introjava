package edu.cscc;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

public class Census {
    public static Surname[] loadCensusData(String fname) {
        Surname[] namelist = new Surname[100];
        int line = 0; // Keep track of lines of file we've read
        //TODO Read from the census file and populate the nameList with Surnames.
        File surnamesCsv = new File(fname);
        //See if we can read the file fname with the try/catch
        try {
            Scanner scanner = new Scanner(surnamesCsv);
            scanner.nextLine();
            //Read the first one hundred surnames in the file. Read each line containing a surname as a single String.
            //This should probably be a method and handle the exception there
            String[] unParsed = new String[100];
            for (int i=0; i < unParsed.length; i++) {
                String surname = scanner.nextLine();
                unParsed[i] = surname;
            }

            //testing to see what it prints out
            System.out.println(unParsed[0]);
            System.out.println(unParsed[99]);
            // example code Integer.parseInt((data.split(",")[1]);




        } catch (FileNotFoundException e) {
            final Surname[] o = null;
            return o;
        }









        return namelist;
    }
}