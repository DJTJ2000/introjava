package edu.cscc;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class SurnameTest {

    private Surname surname;

    @Before
    public void setUp() {
        surname = new Surname("Dresden", 512);
    }

    @Test
    public void itCanGetAndSetTheName() {
        assertEquals("Dresden", surname.getName());
        surname.setName("Murphy");
        assertEquals("Murphy", surname.getName());
    }

    @Test
    public void itCanGetAndSetTheRank() {
        assertEquals(512, surname.getRank());
        surname.setRank(1);
        assertEquals(1, surname.getRank());
    }

}