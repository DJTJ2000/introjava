package edu.cscc;

import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;

import static org.junit.Assert.*;

public class CensusTest {

    private File tempFile;
    private File badRecordsFile;

    @Before
    public void setUp() throws IOException {
        tempFile = new File("./Surnames_2010Census.csv");
        badRecordsFile = new File("test/Surnames_with_invalid_rank_record.csv");
    }

    @Test
    public void itReturnsNullSurnameArrayWhenTheFileCannotBeRead() {
        Surname[] surnames = Census.loadCensusData("file that does not exist.csv");
        assertNull(surnames);
    }

    @Test
    public void itLoadsTheFirst100Surnames() {
        Surname[] surnames = Census.loadCensusData(tempFile.getPath());
        assertEquals(100, surnames.length);

        for (int i=0; i<surnames.length; i++) {
            Surname surname = surnames[i];
            assertNotNull(surname);
            assertNotNull(surname.getName());
            assertNotNull(surname.getRank());
        }
    }

    @Test
    public void itContinuesReadingRecordsWhenANumberFormatExceptionOccurs() {
        Surname[] surnames = Census.loadCensusData(badRecordsFile.getPath());
        assertEquals(100, surnames.length);
    }

    @Test
    public void itPopulatesEachSurname() {
        Surname[] surnames = Census.loadCensusData(tempFile.getPath());
        assertEquals(100, surnames.length);

        Surname firstSurname = surnames[0];
        assertEquals("SMITH", firstSurname.getName());
        assertEquals(1, firstSurname.getRank());

        Surname lastSurname = surnames[surnames.length - 1];
        assertEquals("JIMENEZ", lastSurname.getName());
        assertEquals(100, lastSurname.getRank());
    }
}